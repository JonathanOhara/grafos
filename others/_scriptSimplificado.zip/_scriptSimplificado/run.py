#gera uma saida do EP1

import os
import subprocess
import re

f = open("diretorio,nomeAluno.txt")
m0 = f.readlines()
f.close()

m1 = re.split("\s+", m0[0])
m2 = re.split("\s+", m0[1])
diretorio = m1[0]
nomeAluno = m2[0]

dir1 = diretorio+"\\"+nomeAluno+"\\"
dirEntradas = diretorio+"\\entradas\\"

fout = open("zzz-run.txt", "w")

ep = "ep1\\"
dir2 = dir1+ep
fout.write(dir2+"\n")
os.chdir(dir2)

nomeArquivo = "01.txt"
entrada = dirEntradas+ep+nomeArquivo
nomeArquivo = "z-01.txt"
saida = dir2+nomeArquivo
cmd = "java MatrizDist < "+entrada+" > "+saida
fout.write(cmd+"\n")
myinput = open(entrada)
myoutput = open(saida, 'w')
cmd = "java MatrizDist"
p = subprocess.Popen(cmd, stdin=myinput, stdout=myoutput)
p.wait()
myoutput.flush()
myinput.close()
myoutput.close()

fout.close()
