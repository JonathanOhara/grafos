#compila EP1

import os
import subprocess
import re

f = open("diretorio,nomeAluno.txt")
m0 = f.readlines()
f.close()

m1 = re.split("\s+", m0[0])
m2 = re.split("\s+", m0[1])
diretorio = m1[0]
nomeAluno = m2[0]

dir1 = diretorio+"\\"+nomeAluno+"\\"

fout = open("zzz-compile.txt", "w")

dir2 = dir1+"ep1\\"
fout.write(dir2+"\n")
os.chdir(dir2)
cmd = "javac MatrizDist.java"
fout.write(cmd+"\n")
p = subprocess.Popen(cmd)
p.wait()

fout.close()
